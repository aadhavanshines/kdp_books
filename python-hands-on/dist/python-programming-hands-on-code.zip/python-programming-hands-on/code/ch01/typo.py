print("Hello, Python!)
