print("Hello, Python!")
